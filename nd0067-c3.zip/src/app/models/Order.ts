export type Order = {
  fullname: string;
  address: string;
  cardnumber: string;
  total: number;
};
