import { Product } from "./Product"

export type OrderLine = {
    product:Product,
    quantity: number
}