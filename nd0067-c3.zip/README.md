# C3

## Install and run

1.  Run `npm install -g @angular/cli`
2.  Run `npm i`
3.  Run `ng serve --open`
